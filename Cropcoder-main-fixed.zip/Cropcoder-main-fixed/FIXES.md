# Cropcoder verification and fixes

## Corrected behaviors

- Reconciled the seeded potato listing, order price, reserved stock, logistics fee, savings, and farmer-gain calculations.
- Made order cancellation restore reserved inventory using the target order synchronously and prevent duplicate restoration.
- Strengthened checkout validation for whole-number quantities, stock limits, buyer identity, phone numbers, six-digit pincodes, required delivery fields, and scheduled dates.
- Added a minimum date for scheduled pickup and rejected past scheduled dates.
- Added farmer listing validation for profile completeness, quantity/minimum-order relationships, asking price, pickup location, and non-future harvest dates.
- Reset farmer-form validation state when the listing modal opens or closes.
- Corrected live landing-page and marketplace counts to exclude sold-out and zero-stock listings.
- Corrected the live logistics network to use only active inventory and undelivered orders.

## Validation completed

The following checks pass:

```text
./node_modules/.bin/tsx scripts/smoke-test.ts
./node_modules/.bin/tsc --noEmit
./node_modules/.bin/vite build
```

The smoke test covers all 14 forecast datasets, both preset logistics corridors, seeded order arithmetic, and empty-network route fallbacks. Browser verification covered the marketplace, checkout validation, order creation, order cancellation/refund, inventory restoration, farmer listing validation, forecast switching, route optimization, and order lifecycle rendering. The browser console showed no application exceptions; the only recorded syntax error came from an intentionally malformed developer-console test expression and was corrected before continuing.

## Run locally

Install dependencies with the package manager of choice, then run the Vite development server:

```bash
npm install
npm run dev
```

For a production preview after building:

```bash
npm run build
npm run preview
```
