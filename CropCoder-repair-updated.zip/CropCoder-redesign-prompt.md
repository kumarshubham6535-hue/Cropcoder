# CropCoder redesign and repair prompt

You are improving an existing React + Vite + Tailwind website called **CropCoder**, a direct farm-to-buyer exchange for growers, FPOs, buyers, and logistics partners. Preserve the existing local-first marketplace behavior and client-side data model. Do not modify backend routes, server logic, database schemas, or external APIs unless explicitly requested.

## Primary objective

Turn the site into a polished, trustworthy product experience rather than a sign-in dead end. Visitors must be able to understand the product and browse the marketplace before authenticating. Authentication should be an intentional modal action, not a full-screen gate. Every interactive route should have a clear escape path, usable loading/error state, responsive behavior, and accessible labels/focus states.

## Chosen visual direction: Editorial Fieldwork

Use a warm, editorial agricultural identity inspired by field journals, printed market sheets, and trustworthy cooperative infrastructure. Avoid generic SaaS styling, excessive rounded cards, purple gradients, default Inter typography, neon cyberpunk effects, and empty centered layouts.

- Design movement: contemporary editorial / field-notes utility.
- Palette: paper `#F4F0E5`, deep forest `#123D2D`, forest dark `#08251B`, brass `#C89238`, clay `#B95D45`, ink `#16251E`, muted ink `#667069`, and soft line `#D8D2C4`.
- Typography: `DM Serif Display` for large headlines, `Manrope` for readable interface/body text, and `IBM Plex Mono` for labels, metadata, prices, and field-note markers.
- Signature motifs: thin brass rules, field-note kicker labels, offset brass shadows, square brand mark, editorial split layouts, and restrained paper texture.
- Interaction style: snappy under-300ms transitions, clear pressed states, accessible focus rings, soft entrance reveal, and reduced-motion support.
- Brand voice: direct, grounded, specific, and confident without overpromising. Use copy such as “Move produce with proof, not guesswork.” and “See today’s lots, then move with confidence.”

## Required product changes

1. Replace any first-screen auth gate with a public CropCoder overview page.
2. Make the overview explain the value proposition, show live/local catalog context, show a few real catalog listings, and provide clear actions for browsing, listing harvest, viewing forecasts, planning routes, and opening orders.
3. Keep the shared header visible on public and authenticated screens. Include brand mark, product descriptor, clear active navigation, local/live status, sign-in or signed-in account state, and a mobile navigation control.
4. Use generated CropCoder agricultural imagery for prominent hero and story sections. Reference the persistent asset URLs exactly as provided by the project asset workflow. Use the generated mark as both header logo and favicon.
5. Keep the farmer/FPO dashboard, marketplace, demand forecast, route optimizer, orders, and checkout behavior intact while improving their styling and access paths.
6. Ensure signed-in users clicking “Review your workspace” are taken directly to the farmer workspace, not shown the login modal again.
7. Use “CropCoder” consistently in visible labels, totals, route-planner hub names, price comparisons, metadata, and document title. Remove obsolete KisanDirect labels.
8. Auth modal requirements: dismissible overlay, responsive layout, accessible close control, password visibility affordance, clear validation, signup/forgot-password states, and a clearly labeled local evaluation account if the project contains a seeded demo account. Never imply production authentication when the app is local-only.
9. Local-first backend behavior: read `VITE_SUPABASE_URL` and the public key from environment variables. If they are absent, do not send requests to placeholder URLs, do not start realtime subscriptions, and do not create console/network errors. Keep local fallback data usable. When configured, preserve optional Supabase sync behavior.
10. Checkout must open from the marketplace with quantity validation, delivery details, logistics summary, financial comparison, and a clear total. Do not submit a real order or payment during visual testing without explicit authorization.
11. Preserve accessibility: semantic buttons, visible focus rings, descriptive labels/aria hints, keyboard-reachable modals, adequate color contrast, mobile-safe text wrapping, and reduced-motion support.
12. Keep image/media assets outside the project directory according to the managed webdev asset workflow. Do not put large media files in `client/public` or `client/src/assets`.

## Validation loop

After each meaningful pass:

- Run `pnpm check`.
- Run `pnpm build`.
- Load the public overview on desktop and mobile widths.
- Exercise Overview, Farmer/FPO, Marketplace, Demand signals, Route planner, and Orders.
- Open and dismiss auth, listing, and checkout modals.
- Validate a local demo login only with the project’s documented demo account.
- Validate route simulation and an order lifecycle transition without creating external side effects.
- Inspect browser console and network logs for runtime errors, failed placeholder requests, hydration loops, or broken asset URLs.
- Confirm no horizontal overflow or clipped controls on mobile.
- Take representative desktop/mobile screenshots before delivery.
- Save a checkpoint only after the final validation pass and provide the checkpoint to the user.

## Files changed in the CropCoder repair pass

The primary frontend work was applied to:

- `client/src/App.tsx`
- `client/src/components/LandingPage.tsx`
- `client/src/components/Header.tsx`
- `client/src/components/Footer.tsx`
- `client/src/components/FarmerAuthModal.tsx`
- `client/src/components/CheckoutModal.tsx`
- `client/src/components/MarketplaceView.tsx`
- `client/src/components/LogisticsOptimizerView.tsx`
- `client/src/components/FarmerHub.tsx`
- `client/src/components/DemandForecastView.tsx`
- `client/src/services/supabaseClient.ts`
- `client/src/services/supabaseService.ts`
- `client/src/services/authService.ts`
- `client/src/index.css`
- `client/index.html`
- `ideas.md`

The finished checkpoint is `manus-webdev://4d77bbaf`.
