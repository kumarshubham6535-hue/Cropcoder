# CropCoder audit notes

## Live baseline
- The deployed site at https://cropcoder.vercel.app/ opened to a sparse sign-in wall with a small centered card and no visible way to understand the product first.
- The supplied source includes a richer direct farm-to-buyer marketplace, but App.tsx gated all screens behind `if (!currentUser)`.
- Supabase client had hardcoded fallback URL/key and the app always attempted hydration/realtime, making local-first behavior misleading and potentially noisy.

## Active preview after first pass
- Public overview loads at the managed preview without auth and shows the CropCoder brand, generated agricultural hero imagery, live listing stats, and clear routes into Marketplace, Farmer/FPO, Forecast, Route planner, and Orders.
- Marketplace navigation is reachable without sign-in and renders the existing 14-listing catalog with search, crop/state filters, sold-out toggle, and order actions.
- The header correctly labels the absence of backend configuration as `Local mode` rather than claiming a live Supabase connection.
- Remaining validation: exercise sign-in modal, responsive mobile navigation, order checkout, farmer gate, forecast, route planner, and order screens; check console/network logs after these flows.

## Authentication verification
The new modal opens from the marketplace and is dismissible. The source-provided demo account (`+91 98224 51203` with password `Kisan@123`) successfully signs in and updates the header to show the signed-in farmer, confirming the prior login gate was the main dead-end rather than a broken credential path.

The remaining functional pass should cover farmer workspace access, forecast, route planner, orders, checkout, mobile navigation, and browser console/network warnings.

## Authenticated workspace verification
The demo account reaches the Farmer/FPO workspace successfully. The farmer dashboard renders profile details, AI suggested price, live owned listings, and the `List Harvest Produce` modal. The modal opens with valid date/quantity defaults and clear cancel/publish controls. The public navigation remains available above the authenticated view.

## Forecast verification
The Demand signals screen renders after navigation from the authenticated workspace. It shows a commodity selector, projected demand, fair farmgate price, consumer price, historical arrivals/prices, and forward forecast data without a fatal error.

## Logistics verification
The route planner renders a live-marketplace corridor, unoptimized baseline, optimized multi-farm route, waypoint dispatch list, savings metrics, and a `Simulate Collection` control. Clicking the control changes it to `Dispatch in Transit...` and highlights the current waypoint, confirming the interaction is wired.

## Orders verification
The Orders screen renders the seeded in-transit order with filters, cancellation/removal actions, lifecycle steps, and a payout control. Clicking `Confirm Delivery & Release Farmer Payout` moves the order to Delivered, updates the Active/Delivered counts, displays the success notice, and removes the advancement control as expected.

## Checkout verification
The buyer flow opens a direct purchase and logistics confirmation modal from a listing. Quantity validation, scheduled delivery toggle, buyer contact fields, delivery address, state/district selection, logistics support summary, financial comparison, and total payable are all present. I did not submit the order because that would create a transaction-like state and requires explicit user confirmation.

## Runtime stabilization
After adding explicit `isSupabaseConfigured()` guards to every optional Supabase helper, the reloaded public overview shows no browser-console output. The demand signals route still renders its local forecast dataset, and the request log shows no new placeholder traffic after the reload; older failures remain only as historical entries from the pre-fix session.

The landing workspace CTA was also corrected so signed-in users go directly to the farmer workspace instead of reopening the sign-in modal.
