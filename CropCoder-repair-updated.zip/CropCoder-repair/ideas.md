# CropCoder Design Direction

## Approach 1
**Theme Name:** Editorial Fieldwork

**Very Brief Intro:** A warm, print-inspired agricultural exchange that pairs deep field green with paper, brass, and clay. It should feel like a trusted market ledger made legible for modern growers and buyers.

**Probability:** 0.07

## Approach 2
**Theme Name:** Monsoon Utility

**Very Brief Intro:** A bright, utilitarian interface built around rain-blue, washed stone, and high-visibility action states. It emphasizes clarity, operational confidence, and speed over heritage.

**Probability:** 0.03

## Approach 3
**Theme Name:** Signal Harvest

**Very Brief Intro:** A dark, data-forward product system with restrained lime signals and luminous operational dashboards. It treats forecasting and logistics as the visual center of gravity.

**Probability:** 0.01

## Chosen Approach: Editorial Fieldwork

### Design Movement
Contemporary editorial design with references to agricultural field notebooks, cooperative market ledgers, and modern Swiss information design.

### Core Principles
1. **Make trust visible:** pricing, verification, and delivery states should be scannable before they are decorative.
2. **Use warmth as infrastructure:** paper-toned surfaces and brass accents should make dense operational UI feel human, not sterile.
3. **Compose with asymmetry:** use a strong left editorial rail, offset cards, and full-bleed bands instead of centering every section.
4. **Respect the working user:** controls must be direct, responsive, keyboard accessible, and clear about what happens next.

### Color Philosophy
Deep forest green (#123D2D) is the anchor: it signals stewardship, reliability, and the living source of the product. Ochre brass (#C9923E) is reserved for actions, positive deltas, and moments of value so it reads as earned, not ornamental. Warm paper (#F7F3EA) softens the system and echoes crop sacks, invoices, and field documentation. Ink (#18231D) provides readable contrast without the harshness of pure black. Terracotta (#B86145) is the corrective signal for warnings, cancellations, and operational friction.

### Layout Paradigm
A responsive editorial frame: a sticky, narrow brand rail on large screens; a compact top bar on small screens; a broad hero split into a text-led left column and a live operational snapshot on the right; content sections use offset cards, horizontal dividers, and long-form vertical rhythm. The marketplace should feel like a catalog spread, not a generic dashboard.

### Signature Elements
- A thin brass rule with a small field-note label above major section headers.
- A live-status marker rendered as a brass/green data pip, always paired with explicit text.
- A “market note” treatment: short, high-contrast callouts that look like annotated ledger entries.

### Interaction Philosophy
Every primary interaction gives immediate acknowledgement and a clear next state. Hover states lift or tint rather than glow. Destructive actions are explicit and reversible where possible. Authentication should explain the value of entering the app and expose a demo path for evaluation rather than dropping users into an unexplained wall.

### Animation
Use short, physical transitions with a custom ease-out. On first load, reveal the editorial rail, hero copy, and data panel in a 50ms stagger. Cards translate 4px and gain shadow on hover; buttons compress to 0.97 scale on press. Keep scan/forecast animations subtle and pause them under `prefers-reduced-motion: reduce`. No looping motion should compete with reading or data entry.

### Typography System
Use **DM Serif Display** for the brand lockup and display headings; use **Manrope** for body copy, labels, numbers, and controls. Headings should use confident sentence case with tight tracking; supporting text should use a comfortable 1.55 line height. Use a mono face only for coordinates, IDs, timestamps, and status chips.

### Brand Essence
CropCoder is a direct farm-to-buyer exchange for growers, FPOs, households, and bulk buyers who need fair pricing and dependable dispatch without opaque middle layers.

**Personality:** grounded, transparent, capable.

### Brand Voice
Headlines sound precise and human. CTAs use active verbs and explain the value of the next step. Microcopy is calm, specific, and never overclaims algorithmic certainty.

Example lines:
- “The fair route from harvest to home.”
- “See today’s lots, then move with confidence.”

### Wordmark & Logo
Use a compact symbol combining a crop row, a coding cursor notch, and a ledger corner: three rising green blades contained in an open brass bracket. The symbol should stand alone in the app chrome, while the wordmark uses DM Serif Display with a custom brass terminal on the final “r”.

### Signature Brand Color
**Field Brass — #C9923E.** It is the visual cue for value discovered, verified, and moved into action.

## Style Decisions
- Keep the public home screen accessible before authentication; authentication is an action, not the first unexplained screen.
- Favor explicit status labels over relying on color or animation alone.
- Use local demo account affordances only as clearly labeled evaluation helpers, never as fake social proof.
