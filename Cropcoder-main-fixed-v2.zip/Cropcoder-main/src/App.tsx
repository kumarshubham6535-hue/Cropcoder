import React, { useState, useEffect } from 'react';
import { ProduceListing, MarketplaceOrder } from './types';
import { INITIAL_PRODUCE_LISTINGS, INITIAL_MARKETPLACE_ORDERS } from './data/marketplaceData';
import { Header, ActiveTab } from './components/Header';
import { LandingPage } from './components/LandingPage';
import { FarmerHub } from './components/FarmerHub';
import { MarketplaceView } from './components/MarketplaceView';
import { DemandForecastView } from './components/DemandForecastView';
import { LogisticsOptimizerView } from './components/LogisticsOptimizerView';
import { OrdersView } from './components/OrdersView';
import { Footer } from './components/Footer';

const ORDER_STATUSES = new Set<MarketplaceOrder['status']>([
  'confirmed',
  'aggregated',
  'in_transit',
  'delivered',
  'cancelled',
]);

const isOrderStatus = (value: unknown): value is MarketplaceOrder['status'] =>
  typeof value === 'string' && ORDER_STATUSES.has(value as MarketplaceOrder['status']);

const toFiniteNumber = (value: unknown, fallback = 0): number => {
  const parsed = Number(value);
  return Number.isFinite(parsed) ? parsed : fallback;
};

const toStringValue = (value: unknown, fallback = ''): string =>
  typeof value === 'string' ? value : fallback;

const toIsoDate = (value: unknown, fallback = new Date().toISOString()): string => {
  const candidate = toStringValue(value);
  const parsed = new Date(candidate);
  return candidate && Number.isFinite(parsed.getTime()) ? parsed.toISOString() : fallback;
};

function normalizeCustomListing(item: unknown, index: number): ProduceListing | null {
  if (!item || typeof item !== 'object') return null;
  const record = item as Record<string, unknown>;
  const rawLocation = record.location && typeof record.location === 'object'
    ? record.location as Record<string, unknown>
    : {};
  const quantity = Math.max(0, toFiniteNumber(record.quantityAvailableQuintals));
  const minOrder = Math.max(1, Math.min(
    Math.round(toFiniteNumber(record.minOrderQuintals, 1)),
    Math.max(1, Math.round(quantity)),
  ));
  const grade = record.grade === 'Grade B (Standard)' || record.grade === 'Grade C (Processing)'
    ? record.grade
    : 'Grade A (Premium)';

  return {
    id: toStringValue(record.id, `list-custom-${Date.now()}-${index}`),
    farmerId: toStringValue(record.farmerId, 'farmer-01'),
    farmerName: toStringValue(record.farmerName, 'Verified Farmer'),
    farmerPhone: toStringValue(record.farmerPhone, '+91 98000 00000'),
    isFPO: Boolean(record.isFPO),
    fpoName: toStringValue(record.fpoName) || undefined,
    cropId: toStringValue(record.cropId, 'onion'),
    cropName: toStringValue(record.cropName, 'Fresh Farm Produce'),
    variety: toStringValue(record.variety, 'Standard Grade'),
    grade,
    quantityAvailableQuintals: quantity,
    minOrderQuintals: minOrder,
    askingPricePerQuintal: Math.max(0, toFiniteNumber(record.askingPricePerQuintal)),
    mandiMiddlemanPricePerQuintal: Math.max(0, toFiniteNumber(record.mandiMiddlemanPricePerQuintal)),
    retailConsumerPricePerQuintal: Math.max(0, toFiniteNumber(record.retailConsumerPricePerQuintal)),
    harvestDate: toStringValue(record.harvestDate, new Date().toISOString().split('T')[0]),
    location: {
      village: toStringValue(rawLocation.village, 'Lasalgaon'),
      district: toStringValue(rawLocation.district, 'Nashik'),
      state: toStringValue(rawLocation.state, 'Maharashtra'),
      lat: toFiniteNumber(rawLocation.lat, 20.1448),
      lng: toFiniteNumber(rawLocation.lng, 74.2255),
    },
    pickupPointName: toStringValue(record.pickupPointName, 'Designated Collection Center'),
    createdAt: toIsoDate(record.createdAt),
    status: record.status === 'sold_out' || quantity <= 0 ? 'sold_out' : 'active',
  };
}

function normalizeStoredOrders(value: unknown): MarketplaceOrder[] {
  if (!Array.isArray(value)) return [];

  return value.flatMap((item, index) => {
    if (!item || typeof item !== 'object') return [];
    const record = item as Record<string, unknown>;
    const rawAddress = record.deliveryAddress && typeof record.deliveryAddress === 'object'
      ? record.deliveryAddress as Record<string, unknown>
      : {};
    const status = isOrderStatus(record.status) ? record.status : null;
    const quantity = toFiniteNumber(record.quantityQuintals);
    if (typeof record.id !== 'string' || typeof record.listingId !== 'string' || !status || quantity <= 0) return [];

    return [{
      id: record.id,
      orderNumber: toStringValue(record.orderNumber, `KD-RECOVERED-${index + 1}`),
      listingId: record.listingId,
      cropName: toStringValue(record.cropName, 'Farm Produce'),
      farmerName: toStringValue(record.farmerName, 'Verified Farmer'),
      farmerPhone: toStringValue(record.farmerPhone),
      farmerPickupLocation: toStringValue(record.farmerPickupLocation, 'Designated Collection Center'),
      buyerName: toStringValue(record.buyerName, 'Buyer'),
      buyerPhone: toStringValue(record.buyerPhone),
      buyerType: record.buyerType === 'bulk' ? 'bulk' : 'individual',
      deliveryAddress: {
        district: toStringValue(rawAddress.district, 'Unknown District'),
        state: toStringValue(rawAddress.state, 'Unknown State'),
        addressLine: toStringValue(rawAddress.addressLine, 'Delivery address unavailable'),
        pincode: toStringValue(rawAddress.pincode, '000000'),
      },
      quantityQuintals: quantity,
      pricePerQuintal: Math.max(0, toFiniteNumber(record.pricePerQuintal)),
      produceTotal: Math.max(0, toFiniteNumber(record.produceTotal)),
      logisticsFee: Math.max(0, toFiniteNumber(record.logisticsFee)),
      totalAmount: Math.max(0, toFiniteNumber(record.totalAmount)),
      traditionalChainCost: Math.max(0, toFiniteNumber(record.traditionalChainCost)),
      consumerSavings: toFiniteNumber(record.consumerSavings),
      farmerEarnings: Math.max(0, toFiniteNumber(record.farmerEarnings)),
      farmerGainVsMandi: toFiniteNumber(record.farmerGainVsMandi),
      status,
      createdAt: toIsoDate(record.createdAt),
      estimatedDeliveryDays: Math.max(0, toFiniteNumber(record.estimatedDeliveryDays)),
      logisticsStep: toStringValue(record.logisticsStep, 'Dispatch details pending'),
      isScheduledPickup: Boolean(record.isScheduledPickup),
      scheduledDate: toStringValue(record.scheduledDate) || undefined,
      cancelledAt: toStringValue(record.cancelledAt) || undefined,
      cancellationReason: toStringValue(record.cancellationReason) || undefined,
      cancellationNote: toStringValue(record.cancellationNote) || undefined,
      refundAmount: Number.isFinite(Number(record.refundAmount)) ? Number(record.refundAmount) : undefined,
      refundStatus: record.refundStatus === 'initiated' || record.refundStatus === 'refunded' || record.refundStatus === 'credited'
        ? record.refundStatus
        : undefined,
    } satisfies MarketplaceOrder];
  });
}

export default function App() {
  const [activeTab, setActiveTab] = useState<ActiveTab>('home');

  // Listings state (stored in localStorage with automatic hydration of all state agricultural listings)
  const [listings, setListings] = useState<ProduceListing[]>(() => {
    try {
      const saved = localStorage.getItem('kd_listings_v5') || localStorage.getItem('kd_listings_v2') || localStorage.getItem('kd_listings');
      if (saved) {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed) && parsed.length > 0) {
          // Identify any custom listings created by user
          const initialIds = new Set(INITIAL_PRODUCE_LISTINGS.map(l => l.id));
          const customListings = parsed
            .filter((item: unknown) => {
              if (!item || typeof item !== 'object') return false;
              const id = (item as { id?: unknown }).id;
              return typeof id === 'string' && !initialIds.has(id);
            })
            .map(normalizeCustomListing)
            .filter((listing): listing is ProduceListing => listing !== null);

          return [...INITIAL_PRODUCE_LISTINGS, ...customListings];
        }
      }
    } catch {
      // ignore parse error
    }
    return INITIAL_PRODUCE_LISTINGS;
  });

  // Orders state
  const [orders, setOrders] = useState<MarketplaceOrder[]>(() => {
    try {
      const saved = localStorage.getItem('kd_orders_v6') || localStorage.getItem('kd_orders_v5');
      if (saved) {
        const parsed = JSON.parse(saved);
        const normalizedOrders = normalizeStoredOrders(parsed);
        if (normalizedOrders.length > 0) {
          return normalizedOrders;
        }
      }
    } catch {
      // ignore parse error
    }
    return INITIAL_MARKETPLACE_ORDERS;
  });

  useEffect(() => {
    try {
      localStorage.setItem('kd_listings_v5', JSON.stringify(listings));
    } catch (e) {
      console.warn('Failed to save listings to localStorage', e);
    }
  }, [listings]);

  useEffect(() => {
    try {
      localStorage.setItem('kd_orders_v6', JSON.stringify(orders));
    } catch (e) {
      console.warn('Failed to save orders to localStorage', e);
    }
  }, [orders]);

  // Handler to add new produce from farmer hub
  const handleAddListing = (newListing: ProduceListing) => {
    setListings((prev) => [newListing, ...prev]);
  };

  // Handler when a buyer places an order
  const handlePlaceOrder = (newOrder: MarketplaceOrder) => {
    setOrders((prev) => [newOrder, ...prev]);

    // Update remaining quantity in listing
    setListings((prev) =>
      prev.map((item) => {
        if (item.id === newOrder.listingId) {
          const remaining = Math.max(0, item.quantityAvailableQuintals - newOrder.quantityQuintals);
          return {
            ...item,
            quantityAvailableQuintals: remaining,
            status: remaining <= 0 ? 'sold_out' : item.status,
          };
        }
        return item;
      })
    );

    // Switch to Orders view so buyer sees real-time logistics steps & price certificate
    setActiveTab('orders');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  // Handler when buyer/farmer cancels a delivery
  const handleCancelOrder = (orderId: string, reason: string, note?: string) => {
    // Resolve the order before scheduling state updates. Reading these values from
    // inside a setState updater made stock restoration timing-dependent in React.
    const targetOrder = orders.find((order) => order.id === orderId);
    if (!targetOrder || targetOrder.status === 'cancelled' || targetOrder.status === 'delivered') {
      return;
    }

    const targetListingId = targetOrder.listingId;
    const targetQty = Number.isFinite(targetOrder.quantityQuintals)
      ? Math.max(0, targetOrder.quantityQuintals)
      : 0;

    setOrders((prev) =>
      prev.map((order) => {
        if (order.id === orderId) {
          return {
            ...order,
            status: 'cancelled' as const,
            cancelledAt: new Date().toISOString(),
            cancellationReason: reason || 'Customer requested delivery cancellation',
            cancellationNote: note,
            refundAmount: order.totalAmount,
            refundStatus: 'initiated' as const,
            logisticsStep: `Delivery Cancelled • 100% Refund (₹${order.totalAmount.toLocaleString('en-IN')}) initiated • Produce returned to farmer inventory`,
          };
        }
        return order;
      })
    );

    // Return stock back to the active produce listing exactly once.
    if (targetListingId && targetQty > 0) {
      setListings((prev) =>
        prev.map((item) => {
          if (item.id === targetListingId) {
            const restoredQty = Math.max(0, item.quantityAvailableQuintals) + targetQty;
            return {
              ...item,
              quantityAvailableQuintals: restoredQty,
              status: 'active',
            };
          }
          return item;
        })
      );
    }
  };

  // Handler to advance order status lifecycle (confirmed -> aggregated -> in_transit -> delivered)
  const handleUpdateStatus = (orderId: string, newStatus: MarketplaceOrder['status']) => {
    setOrders((prev) =>
      prev.map((order) => {
        if (order.id === orderId) {
          let stepDescription = order.logisticsStep;
          if (newStatus === 'aggregated') {
            stepDescription = `Produce aggregated & inspected at ${order.farmerPickupLocation || 'Collection Center'} • Barcode batch assigned`;
          } else if (newStatus === 'in_transit') {
            stepDescription = `Dispatched via multi-farm TSP cold-chain vehicle • En route to ${order.deliveryAddress?.district || 'Buyer Destination'}`;
          } else if (newStatus === 'delivered') {
            stepDescription = `Successfully delivered to ${order.buyerName} • Direct farmer payout (₹${order.produceTotal.toLocaleString('en-IN')}) settled`;
          }
          return {
            ...order,
            status: newStatus,
            logisticsStep: stepDescription,
          };
        }
        return order;
      })
    );
  };

  // Handler to permanently delete/dismiss an order record
  const handleDeleteOrder = (orderId: string) => {
    setOrders((prev) => prev.filter((order) => order.id !== orderId));
  };

  return (
    <div className="min-h-screen bg-[#FDFBF7] text-stone-900 flex flex-col font-sans selection:bg-[#D4A24E] selection:text-[#1B4332]">
      {/* Top Navigation */}
      <Header
        activeTab={activeTab}
        onSelectTab={(tab) => {
          setActiveTab(tab);
          window.scrollTo({ top: 0, behavior: 'smooth' });
        }}
        ordersCount={orders.filter(o => o.status !== 'cancelled').length}
      />

      {/* Main View Router */}
      <main className="flex-1">
        {activeTab === 'home' && (
          <LandingPage
            listings={listings}
            onSelectTab={(tab) => {
              setActiveTab(tab);
              window.scrollTo({ top: 0, behavior: 'smooth' });
            }}
          />
        )}

        {activeTab === 'farmer' && (
          <FarmerHub
            listings={listings}
            onAddListing={handleAddListing}
          />
        )}

        {activeTab === 'buyer' && (
          <MarketplaceView
            listings={listings}
            onPlaceOrder={handlePlaceOrder}
          />
        )}

        {activeTab === 'forecast' && (
          <DemandForecastView />
        )}

        {activeTab === 'logistics' && (
          <LogisticsOptimizerView
            listings={listings}
            orders={orders}
          />
        )}

        {activeTab === 'orders' && (
          <OrdersView
            orders={orders}
            onCancelOrder={handleCancelOrder}
            onDeleteOrder={handleDeleteOrder}
            onUpdateStatus={handleUpdateStatus}
          />
        )}
      </main>

      {/* Footer */}
      <Footer />
    </div>
  );
}
