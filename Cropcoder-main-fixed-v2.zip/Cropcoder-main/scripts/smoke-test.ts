import assert from 'node:assert/strict';
import { INITIAL_MARKETPLACE_ORDERS, INITIAL_PRODUCE_LISTINGS } from '../src/data/marketplaceData';
import { REGIONAL_HISTORICAL_DATASETS } from '../src/data/forecastingData';
import { generateCropForecast } from '../src/services/forecastingEngine';
import { LOGISTICS_CORRIDORS, optimizeCustomRoute, optimizeLogisticsRoute } from '../src/services/logisticsEngine';

const seededOrder = INITIAL_MARKETPLACE_ORDERS[0];
const seededListing = INITIAL_PRODUCE_LISTINGS.find((listing) => listing.id === seededOrder.listingId);
assert.ok(seededListing, 'Seeded order must reference an existing listing');
assert.equal(
  seededListing!.quantityAvailableQuintals + seededOrder.quantityQuintals,
  120,
  'Seeded listing stock must equal original stock less the reserved order quantity',
);
assert.equal(seededOrder.produceTotal, seededOrder.quantityQuintals * seededOrder.pricePerQuintal);
assert.equal(seededOrder.totalAmount, seededOrder.produceTotal + seededOrder.logisticsFee);
assert.equal(seededOrder.traditionalChainCost - seededOrder.totalAmount, seededOrder.consumerSavings);
assert.equal(
  seededOrder.farmerEarnings - seededOrder.quantityQuintals * seededListing!.mandiMiddlemanPricePerQuintal,
  seededOrder.farmerGainVsMandi,
);

for (const dataset of REGIONAL_HISTORICAL_DATASETS) {
  const forecast = generateCropForecast(dataset.cropId);
  assert.equal(forecast.cropId, dataset.cropId);
  assert.ok(Number.isFinite(forecast.predictedDemandQuintals) && forecast.predictedDemandQuintals > 0);
  assert.ok(Number.isFinite(forecast.suggestedFarmerPrice) && forecast.suggestedFarmerPrice > 0);
  assert.equal(forecast.next3MonthsForecast.length, 3);
  assert.equal(forecast.historicalData.length, dataset.history.length);
}

for (const [key, corridor] of Object.entries(LOGISTICS_CORRIDORS)) {
  const result = optimizeLogisticsRoute(key);
  assert.equal(result.pickups.length, corridor.pickups.length);
  assert.equal(result.dropoffs.length, corridor.dropoffs.length);
  assert.equal(result.orderedWaypoints[0].id, corridor.hub.id);
  assert.ok(result.totalDistanceKm > 0);
  assert.ok(result.unoptimizedDistanceKm >= result.totalDistanceKm);
  assert.ok(result.distanceSavedKm >= 0);
  assert.ok(Number.isFinite(result.logisticsCostPerQuintalInr));
}

const liveRoute = optimizeCustomRoute(
  LOGISTICS_CORRIDORS.maharashtra_western.hub,
  [],
  [],
  'SMOKE',
);
assert.ok(liveRoute.pickups.length > 0 && liveRoute.dropoffs.length > 0);
assert.ok(liveRoute.orderedWaypoints.length >= 4);

console.log(`Smoke tests passed: ${REGIONAL_HISTORICAL_DATASETS.length} forecasts, ${Object.keys(LOGISTICS_CORRIDORS).length} corridors, seeded order integrity, and live-route fallbacks.`);
